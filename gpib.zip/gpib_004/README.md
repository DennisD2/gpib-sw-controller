# GPIB software only controller code.
