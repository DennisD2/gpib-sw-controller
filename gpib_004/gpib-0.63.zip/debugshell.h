/*************************************************************************
Author:   	$Author: dennis $
File:     	$HeadURL: file:///home/dennis/svn-store/avr-source/gpib_004/debugshell.h $
Date:  		$Date: 2008-04-29 22:10:57 +0200 (Di, 29 Apr 2008) $ 
Revision: 	$Revision: 56 $ 
Id: 		$Id: debugshell.h 56 2008-04-29 20:10:57Z dennis $ 
Licence:	GNU General Public License

DESCRIPTION:
  debug shell implementation. 
 *************************************************************************/
#ifndef DEBUGSHELL_H_
#define DEBUGSHELL_H_

#include "defs.h"

extern void debugshell( void );


#endif /*TIMER16_H_*/
