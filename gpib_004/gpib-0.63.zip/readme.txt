
Code Description
----------------
This code implements a kind of a GPIB controller. It understands a few built in commands.

The hardware should be connected via GPIB interface, the controlling computer/terminal via RS232.
Then the following commands can be used:
.a <n> - set partner device address to value <n>. <n> is the GPIB device adress, e.g. 3.
	the partner device is the device to control.
.d - switch to debug shell mode. In debug shell mode, some low level GPIB bus commands are possible:
	i - print out status of some GPIB lines
	x - exit debug shell
When in normal input mode, device commands can be entered. For commands that will have an answer
from the device under control, the answer is print out to the terminal. The controller is also
able to do a serial poll.

The code was tested with a Tektronix 2432a oscilloscope and with a Tektronix 1241 logic analyzer.
The implementation may be specific to Tektronix and may not work with other devices. 

D.Dingeldein

--------


List of good test commands:
--------------------------
Tek 2432a
INIT
MEASUREMENT WINDOW:ON
CURSOR FUNCTION: TIME,TARGET:CH1,UNITS:TIME:BASE
CURSOR TPOS:ONE:200,TPOS:TWO:500
message 5:"dennis testet hier auch"
ID?
RUN?
CH1?
wavfrm?
curve?
wfmpre?
data encdg:ascii


Tek 1241
id?
dt?
refmem?
