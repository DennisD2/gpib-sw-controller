/*************************************************************************
Author:   	$Author: dennis $
File:     	$HeadURL: file:///home/dennis/svn-store/gpib_004/defs.h $
Date:  		$Date: 2008-03-26 19:03:40 +0100 (Mi, 26 Mrz 2008) $ 
Revision: 	$Revision: 43 $ 
Id: 		$Id: defs.h 43 2008-03-26 18:03:40Z dennis $ 
Licence:	GNU General Public License

DESCRIPTION:
          standard definitions used in all .h and .c files of project
 *************************************************************************/
#ifndef DEFS_H_
#define DEFS_H_

typedef unsigned char uchar;
typedef unsigned int uint;
typedef unsigned long ulong;

#ifndef F_CPU
#error "You must define F_CPU value (cpu frequency in hz)"
/*#define F_CPU 1000000*/
#endif

#define UART_BAUD_RATE      19200     /* baudrate, e.g 19200 */
#define DI() uart_init( UART_BAUD_SELECT(UART_BAUD_RATE,F_CPU) )
#define DO( m ) uart_puts(m)

#endif /*DEFS_H_*/
