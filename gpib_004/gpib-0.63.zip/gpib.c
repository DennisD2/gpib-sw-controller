/*************************************************************************
Author:   	$Author: dennis $
File:     	$HeadURL: file:///home/dennis/svn-store/avr-source/gpib_004/gpib.c $
Date:  		$Date: 2008-05-10 11:38:04 +0200 (Sa, 10 Mai 2008) $ 
Revision: 	$Revision: 64 $ 
Id: 		$Id: gpib.c 64 2008-05-10 09:38:04Z dennis $ 
Licence:	GNU General Public License

DESCRIPTION:
  GPIB implementation. 
  For GPIB bus, negative logic is used. This means "active" is LOW and 
  "not active" is HIGH.
 *************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <avr/io.h>
#include <string.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>

#include "uart.h"

#include "gpib.h"
#include "timer16.h"
#include "debugshell.h"

uchar _gpib_write( uchar *bytes, int length, uchar attention ) ;

// if set, WITH_TIMEOUT means that waitings are interruptable by timeout.
// if not set, code stays in waiting maybe forever.
#define WITH_TIMEOUT

//
// Open Collector bit handling
// release : means set to HIGH
// assign: means set to LOW
// If not open collector, we would use:
//							bit is output, set bit to 1
//                     #define release_bit(p,b) p |= _BV(b)
//							bit is output, set bit to 0
//                     #define assign_bit(p,b)  p &= ~_BV(b)
//							bit to input, switch pullup on
#define release_bit(d,p,b) d &= ~_BV(b); p |= _BV(b);
//							bit is unknown, set bit to 0, bit to output, set bit to 0
#define assign_bit(d,p,b)  p &= ~_BV(b); d |= _BV(b); p &= ~_BV(b);

// controller object
gpib_controller_t controller;

// 1 if data valid, 0 else
uchar dav;
// 1 if eoi detected, 0 else
uchar eoi;
// command buffer 
uchar cmd_buf[100];

//
// some delay function
//
void delay_ms(unsigned short ms)
{
	unsigned short outer1, outer2;
	outer1 = 200*12;

	while (outer1) {
		outer2 = 100;
		while (outer2) {
			while (ms )
				ms--;
			outer2--;
		}
		outer1--;
	}
}

//
// \brief init GPIB pins and variables. All signal lines not related to the controller part
// 		are initialized with useful values. 
//		(The controller part initialization is done oin gpib_controller_assert())
//
void gpib_init( void ) {
	// data lines - complete port A as input
	DDRA = 0x00;

	// handshake lines - on port D , evrything as input 
	DDRD &= ~_BV(G_DAV); // DAV 
	DDRD &= ~_BV(G_EOI); // EOI 
	DDRD &= ~_BV(G_SRQ); // SRQ 
	DDRD &= ~_BV(G_ATN); // ATN  
	DDRB &= ~_BV(G_REN); // REN  
	DDRB &= ~_BV(G_IFC); // IFC  

	// init handshake lines
	assign_bit(DDRD,PORTD,G_NRFD);// not ready for data now
	release_bit(DDRD,PORTD,G_NDAC);// initially: ok so far

	dav=0; // no valid data in the moment
	eoi=0; // init end of transmission flag 
}

// 
// \brief Receive a character, busy waiting until timeout value is reached. Then, 
//		the debugshell function is entered for user handling of the problem.
// \param _byte 	Pointer to single character; the function stores herein the character read. 
//		When errors occur during the function, the content of the parameter (i.e. *_byte) is undefined.
// \returns		On any error, 0xff is returned. in this case, the value of parameter *_byte is undefined.
//		Otherwisse the value of the EOI signal line during read is returned. If EOI was assigned, a 0x01 is 
//		returned. If EOI was not assigned, a 0x00 is returned. Assignment of EOI means that the talker 
//		is sending the last character for this transmission.
//
uchar gpib_receive( uchar* _byte ) { 
	int timeout;
	uchar byte;

	//uart_puts("\n\rgpib_read()\n\r");

	if (controller.talks==1) {
		*_byte = 0xff;
		return 0xff;
	}

	// handshake: set nrfd, means i am ready to receive some data
	release_bit(DDRD,PORTD,G_NRFD);
	assign_bit(DDRD,PORTD,G_NDAC);

	//gpib_info();

#ifdef WITH_TIMEOUT
	timeout=s+5;
	//gpib_info();
	while ((PIND & _BV(G_DAV)) && (s<=timeout)) {
		if (s==timeout) {
			uart_puts("\n\rError: DAV timeout (1)\n\r");
			//gpib_info();
			debugshell();
			return 0xff;
		}
	}
#else
	loop_until_bit_is_clear(PIND,G_DAV);
#endif

	// handshake: clear NRFD, means i am busy now to read data
	assign_bit(DDRD,PORTD,G_NRFD);
	// read data
	byte = PINA ^ 0xff;

	// handshake: set ndac, means i have completed/accepted the read
	release_bit(DDRD,PORTD,G_NDAC);

#ifdef WITH_TIMEOUT
	timeout=s+5;
	//gpib_info();
	while (!(PIND & _BV(G_DAV)) && (s<=timeout)) {
		if (s==timeout) {
			uart_puts("\n\rError: DAV timeout (2)\n\r");
			//gpib_info();
			debugshell();
			return 0xff;
		}
	}
#else
	loop_until_bit_is_set(PIND,G_DAV);
#endif
	// handshake: clear ndac (this is a prerequisite for receive next byte)
	assign_bit(DDRD,PORTD,G_NDAC);

	// check if last byte of transmission
	eoi = bit_is_clear(PIND,G_EOI);

	*_byte = byte;

	return eoi; 
}

//
// assign bus to me
// 
void gpib_controller_assign( uchar address ) {	
	controller.myaddress = address;
	controller.talks=0;
	controller.partneraddress=0x01; // init active partner
	controller.partners[0] = 0x01; // init partner array - this is specific and should not be done in a static way
	controller.partners[1] = 0x02; // but for me, its ok
	controller.partners[3] = 0x00; // end value is 0x00

	// set up initial state of bus
	assign_bit( DDRB, PORTB, G_IFC );
	delay_ms(200);
	release_bit( DDRB, PORTB, G_IFC );
	// set up all devices for remote control
	assign_bit( DDRB, PORTB, G_REN );

	// DCL - device clear for all devices on bus
	cmd_buf[0] = G_CMD_DCL;
	gpib_cmd( cmd_buf, 1 );
}

//
// release bus 
// 
void gpib_controller_release( void ) {
	// set up initial state of bus
	assign_bit( DDRB, PORTB, G_IFC );
	delay_ms(200);
	release_bit( DDRB, PORTB, G_IFC );
	// set up all devices for local control
	release_bit( DDRB, PORTB, G_REN );
}

//
// write GPIB string to bus
// See _gpib_write() for further information.
//
uchar gpib_write( uchar *bytes, int length ) {
	// set attention arg false for ordinary strings
	return _gpib_write(bytes, length, (uchar)0 );
}

//
// write GPIB command to bus
// See _gpib_write() for further information.
//
uchar gpib_cmd( uchar *bytes, int length ) {
	// set attention arg true for commands
	return _gpib_write(bytes, length, (uchar)1 );
}

//
// Write byte array to the bus.
// bytes: byte array containing bytes to be send
// length: length of valid bytes in byte array or zero. 
// for binary data, lenght must be defined. For strings, length can be set to zero. Then the length of
// the string is calculated internally.
// Precondition: Device must be allowed to talk. For a controller, this means all
// other devices have been set to be listeners.
//
uchar _gpib_write( uchar *bytes, int length, uchar attention ) {
	uchar c;
	int i;
	int timeout;
	//uchar buf[64];

	// set talks state. This is used by ISR to recognize own talk
	// (controller must not talk to itself and must not take part in listener handshake when talking)
	controller.talks=1;

	if (attention) {
		//uart_puts("\n\rgpib_controller_write()\n\r");
		// assign ATN for commands
		assign_bit( DDRD, PORTD, G_ATN );
	}

	if (length==0) {
		// length==0 means this is a common C string, null-terminated.
		// then, length can be easily calculated
		length = strlen((char*)bytes);
	}
	// for debugging print out
	//	bytes[length]=0x00;
	//	if (length>1)
	//		sprintf( buf, "gpib_write: %s\n\r", (char *)bytes );
	//	else 
	//		sprintf( buf, "gpib_write: 0x%02x\n\r", bytes[0] );
	//	uart_puts((char*)buf);

	// release EOI during transmission
	release_bit(DDRD,PORTD,G_EOI);
	// release DAV, data not valid anymore
	release_bit(DDRD,PORTD,G_DAV);
	// release NRFD (just to be sure)
	release_bit(DDRD,PORTD,G_NRFD);


	// bytes[0] = 'a'
	// bytes[1] = 'b'
	// length = 2
	for (i=0; i<length; i++ ) {

		// put data on bus
		c = bytes[i];
		//sprintf( buf, "char: %c\n\r", c );
		//uart_puts(buf);		

		release_bit(DDRD,PORTD,G_NDAC);
		//uart_puts("0");
		// wait for NDAC assign from all listeners
#ifdef WITH_TIMEOUT
		timeout=s+5;
		//gpib_info();
		while ((PIND & _BV(G_NDAC)) && (s<=timeout)) {
			if (s==timeout) {
				uart_puts("\n\rError: NDAC timeout\n\r");
				//gpib_info();
				debugshell();
				return 0xff;
			}
		}
#else
		loop_until_bit_is_clear(PIND,G_NDAC);	
#endif

		DDRA = 0x00;
		if (c&0x01) {
			assign_bit(DDRA,PORTA,PA0);
		} else {
			release_bit(DDRA,PORTA,PA0)
		}

		if (c&0x02) {
			assign_bit(DDRA,PORTA,PA1) 
		} else {
			release_bit(DDRA,PORTA,PA1);
		}

		if (c&0x04) {
			assign_bit(DDRA,PORTA,PA2);
		} else {
			release_bit(DDRA,PORTA,PA2);
		}

		if (c&0x08) {
			assign_bit(DDRA,PORTA,PA3);
		} else {
			release_bit(DDRA,PORTA,PA3);
		}

		if (c&0x10) {
			assign_bit(DDRA,PORTA,PA4);
		} else {
			release_bit(DDRA,PORTA,PA4);
		}

		if (c&0x20) {
			assign_bit(DDRA,PORTA,PA5);
		} else {			
			release_bit(DDRA,PORTA,PA5);
		}

		if (c&0x40) {
			assign_bit(DDRA,PORTA,PA6);
		} else {
			release_bit(DDRA,PORTA,PA6);
		}

		if (c&0x80) {
			assign_bit(DDRA,PORTA,PA7);
		} else {
			release_bit(DDRA,PORTA,PA7);
		}

		// wait until listeners release NRFD
		//uart_puts("1");
		release_bit(DDRD,PORTD,G_NRFD);
#ifdef WITH_TIMEOUT
		//gpib_info();
		timeout=s+5;
		while (!(PIND & _BV(G_NRFD)) && (s<=timeout)) {
			if (s==timeout) {
				uart_puts("\n\rError: NRFD timeout\n\r");
				//gpib_info();
				debugshell();
				return 0xff;
			}
		}
#else
		loop_until_bit_is_set(PIND,G_NRFD);	
#endif

		// assign EOI during transmission of only last byte
		if ((i==length-1) && !attention) {
			//uart_puts("\n\rE\n\r");
			assign_bit(DDRD,PORTD,G_EOI);
		}

		// assign DAV, data valid for listeners
		assign_bit(DDRD,PORTD,G_DAV);

		// wait for NDAC release
		//uart_puts("2");
		release_bit(DDRD,PORTD,G_NDAC);
		loop_until_bit_is_set(PIND,G_NDAC);

		// release DAV, data not valid anymore
		release_bit(DDRD,PORTD,G_DAV);

		// reset Port to all input
		DDRA = 0x00;

		//uart_puts("3\r\n");
	}

	if (attention) {
		// assign ATN for commands
		release_bit( DDRD, PORTD, G_ATN );
	}

	// clear talk state.Controller does not talk anymore.
	controller.talks=0;

	return 0x00;
}

//
// print some useful info about bus state (e.g. value of handshake pins)
//
void gpib_info( void ) {
	uchar b1,b2,b3,b4,b5,b6,b7,b8;
	char buf[80];

	b1 = bit_is_set(PIND,G_DAV);
	b2 = bit_is_set(PIND,G_NRFD); 
	b3 = bit_is_set(PIND,G_NDAC);
	b4 = bit_is_set(PIND,G_EOI);
	b5 = bit_is_set(PIND,G_ATN);
	b6 = bit_is_set(PIND,G_SRQ);
	b7 = bit_is_set(PINB,G_IFC);
	b8 = bit_is_set(PINB,G_REN);
	//d = PINA;
	//di = d ^ 0xff;
	if (b1==0x00) b1='0'; else b1='1';
	if (b2==0x00) b2='0'; else b2='1';
	if (b3==0x00) b3='0'; else b3='1';
	if (b4==0x00) b4='0'; else b4='1';
	if (b5==0x00) b5='0'; else b5='1';
	if (b6==0x00) b6='0'; else b6='1';
	if (b7==0x00) b7='0'; else b7='1';
	if (b8==0x00) b8='0'; else b8='1';

	sprintf( buf, "dav=%c,nrfd=%c,ndac=%c, eoi=%c, ifc=%c,ren=%c,atn=%c,srq=%c\n\r", 
			b1, b2, b3, b4, b7, b8, b5, b6  );
	uart_puts(buf);
}

//
// execute serial polling
//
uchar gpib_serial_poll( uchar adr1, uchar adr2, uchar adr3 ) {
	uchar b,e;
	uchar address=0, found=0;
	int i;

	// send UNT and UNL commands (unlisten and untalk)
	// effect: all talker stop talking and all listeners stop listening
	cmd_buf[0] = G_CMD_UNT;
	gpib_cmd( cmd_buf, 1 );
	cmd_buf[0] = G_CMD_UNL;
	gpib_cmd( cmd_buf, 1 );

	// serial poll enable
	// effect: all devices will send status byte instead of normal data when addressed
	// as talker
	//uart_puts("before SPE\r\n");
	cmd_buf[0] = G_CMD_SPE;
	gpib_cmd( cmd_buf, 1 );
	//uart_puts("after SPE\r\n");

	// searching for SRQ emitter in a loop ...
	for (i=0; (controller.partners[i]!=0x00) && !found; i++ ) {

		// set partner to talker mode
		address = talker_address( controller.partners[i] );
		cmd_buf[0] = address;
		//uart_puts("before talker adress write\r\n");
		gpib_cmd( cmd_buf, 1 );
		//uart_puts("after talker adress write\r\n");

		// now receive data
		//uart_puts("before status byte receive\r\n");
		e = gpib_receive(&b);
		//uart_puts("after status byte receive\r\n");
		// status byte is now in b
		sprintf( (char*)cmd_buf, "status byte from device 0x%02x = 0x%02x (char=%c)\r\n", address, b, b );
		uart_puts((char*)cmd_buf);

		// send UNT and UNL commands (unlisten and untalk)
		// effect: all talker stop talking and all listeners stop listening
		cmd_buf[0] = G_CMD_UNT;
		gpib_cmd( cmd_buf, 1 );
		cmd_buf[0] = G_CMD_UNL;
		gpib_cmd( cmd_buf, 1 );

		if (b & (1<<6)) {
			found = address;
			// bit 6 of status byte of SRQ emitter is 1
			// when reading status byte from emitter, he releases SRQ line (may also be tested here)
			sprintf( (char*)cmd_buf, "SRQ emitter is device = 0x%02x\n\r", found );
			uart_puts((char*)cmd_buf);
		}
	}
	
	// serial poll disable
	// effect: all devices will return to normal behaviour as talker
	cmd_buf[0] = G_CMD_SPD;
	//uart_puts("before SPD\r\n");
	gpib_cmd( cmd_buf, 1 );
	//uart_puts("after SPD\r\n");

	// return SRQ emitter address if found
	return found;
}

void gpib_set_partner( uchar address ) {
	controller.partneraddress = address;
}

uchar gpib_get_partner( void ) {
	return controller.partneraddress;
}

uchar gpib_get_address( void ) {
	return controller.myaddress;
}
