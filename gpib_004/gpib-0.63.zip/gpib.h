/*************************************************************************
Author:   	$Author: dennis $
File:     	$HeadURL: file:///home/dennis/svn-store/avr-source/gpib_004/gpib.h $
Date:  		$Date: 2008-05-10 07:43:13 +0200 (Sa, 10 Mai 2008) $ 
Revision: 	$Revision: 63 $ 
Id: 		$Id: gpib.h 63 2008-05-10 05:43:13Z dennis $ 
Licence:	GNU General Public License

DESCRIPTION:
  GPIB implementation. 
 *************************************************************************/
#ifndef GPIB_H_
#define GPIB_H

#include "defs.h"

// Handshake lines: DAV, NRFD and NDAC on Port D
#define G_DAV  PD2
#define G_NRFD PD3
#define G_NDAC PD5

// management lines: EOI, SRQ and ATN on Port D, IFC and REN on Port B
#define G_EOI  PD4
#define G_SRQ  PD6
#define G_ATN  PD7
#define G_IFC  PB0
#define G_REN  PB1

// GPIB command codes
#define G_CMD_UNL 0x3f
#define G_CMD_UNT 0x5f
#define G_CMD_SPE 0x18
#define G_CMD_SPD 0x19
#define G_CMD_DCL 0x14

#define listener_address(device) (device+0x20)
#define talker_address(device) (device+0x40)

#define MAX_PARTNER 5 /* max. site of active partner list */

typedef struct {
	uchar myaddress; /* controller adress,usually 0x00 */
	uchar partneraddress; /* currently adressed partner device */
	uchar talks; /* true while controller is talker, */
	uchar partners[MAX_PARTNER]; /* list of active partners */
	uchar num_partners; /* number of active partners */
} gpib_controller_t;

// management functions for controller
extern void gpib_init( void );
extern void gpib_controller_assign( uchar address );
extern void gpib_controller_release( void );
extern uchar gpib_cmd( uchar *bytes, int length );
uchar gpib_serial_poll( uchar adr1, uchar adr2, uchar adr3 );
extern void gpib_set_partner( uchar address );
extern uchar gpib_get_partner( void );
extern uchar gpib_get_address( void );

// listener functions
extern uchar gpib_receive( uchar *byte );

// talker funtions
extern uchar gpib_write( uchar *bytes, int length );

// just for code testing
extern void gpib_info( void );

//extern volatile uchar srq;

#endif /*GPIB_H_*/
