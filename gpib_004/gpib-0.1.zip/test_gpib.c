
/*************************************************************************
Author:   	$Author: dennis $
File:     	$HeadURL: file:///home/dennis/svn-store/gpib_004/test_gpib.c $
Date:  		$Date: 2008-03-26 19:03:40 +0100 (Mi, 26 Mrz 2008) $ 
Revision: 	$Revision: 43 $ 
Id: 		$Id: test_gpib.c 43 2008-03-26 18:03:40Z dennis $ 
Licence:	GNU General Public License

DESCRIPTION:
  GPIB implementation test - a simple controller
 *************************************************************************/

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <stdio.h>

#include "uart.h"
#include "gpib.h"
#include "timer16.h"

/*
 * Compatibility defines. This should work on ATmega8, ATmega16,
 * ATmega163, ATmega323 and ATmega128 (IOW: on all devices that
 * provide a builtin TWI interface).
 *
 * On the 128, it defaults to USART 1.
 */
#ifndef UCSRB
# ifdef UCSR1A /* ATmega128 */
# define UCSRA UCSR1A
# define UCSRB UCSR1B
# define UBRR UBRR1L
# define UDR UDR1
# else /* ATmega8 */
# define UCSRA USR
# define UCSRB UCR
# endif
#endif
#ifndef UBRR
# define UBRR UBRRL
#endif

uchar input_process( void );

uchar device_address = 0x01; // address of GPIB device (in my case, my oszillocope)
uchar buf[64], cmd_buf[64];
int buf_ptr=0;

/*
 * Do all the startup-time peripheral initializations: UART (for our
 * debug/test output), and TWI clock.
 */
void ioinit(void) {
	UCSRB = _BV(TXEN) | _BV(RXEN); /* tx/rx enable */
	UBRR = (F_CPU / (16 * 19200UL)) - 1; /* 19200 Bd */
	/* initialize TWI clock: 100 kHz clock, TWPS = 0 => prescaler = 1 */
#if defined(TWPS0)
	/* has prescaler (mega128 & newer) */
	TWSR = 0;
#endif
	TWBR = (F_CPU / 100000UL - 16) / 2;
}

int main(void) {
	uchar b,e;
	uchar address;
	int old_time=0;
	uchar srq;
	uchar is_query=0;
	uchar command_ready=0;

	/*
	 *  Initialize UART library, pass baudrate and avr cpu clock 
	 *  with the macro UART_BAUD_SELECT()
	 */
	/*uart_init( UART_BAUD_SELECT(UART_BAUD_RATE,XTAL_CPU) );*/
	DI();

	/*
	 * now enable interrupt, since UART and TIMER library is interrupt controlled
	 */
	sei();

#define WRITE
#ifdef WRITE
	uart_puts("\n\rGPIB Controller (T/L/C)\n\r> ");

	//
	// WRITE TEST - Controller talks and listens
	//
	
	// init timer for timeout detection
	timer16_init();

	// init gpib lines
	gpib_init();
	// init controller part - assign bus 
	gpib_controller_assign();

	// controller loops forever:
	// 1. try to read command from user
	// 2. send user entered command, if available, to listeners (act as talker, set devices to listeners)
	// 3. if command was a query, read the answer from device (become listener and set device to talker)
	// 4. check if SRQ occured and handle that
	for(;;) {

		// input processing via rs232
		// command_ready may already been set by SRQ that occured before
		if (!command_ready)
			command_ready = input_process();

		// if a command was entered, send it to listeners
		if (command_ready) {
			uart_puts("\n\r");

			// send UNT and UNL commands (unlisten and untalk)
			// effect: all talker stop talking and all listeners stop listening
			cmd_buf[0] = G_CMD_UNT;
			gpib_cmd( cmd_buf, 1 );
			cmd_buf[0] = G_CMD_UNL;
			gpib_cmd( cmd_buf, 1 );

			// set device (oszi) to listener mode
			address = listener_address(device_address);
			cmd_buf[0] = address;
			gpib_cmd( cmd_buf, 1 );

			// set myself (controller) to talker mode
			address = talker_address(0);
			cmd_buf[0] = address;
			gpib_cmd( cmd_buf, 1 );

			// put out command to listeners
			uart_puts("command: ");
			uart_puts(buf);
			uart_puts("\n\r");
			// gpib bus write
			gpib_write( buf, 0 );

			// check if query or command only
			// all queries end with '?'
			if ((buf_ptr>0) && (buf[buf_ptr-1]=='?')) {
				uart_puts("Query. Will check for answer.\n\r");
				is_query=1;
			} else {
				uart_puts("Command only.\n\r> ");
				is_query=0;
			}

			// reset local vars for command string reading
			buf_ptr=0;
			command_ready=0;
		}

		// if we sent a query, read the answer
		if (is_query) {
			// UNT and UNL
			cmd_buf[0] = G_CMD_UNT;
			gpib_cmd( cmd_buf, 1 );
			cmd_buf[0] = G_CMD_UNL;
			gpib_cmd( cmd_buf, 1 );

			// set device (oszi) to talker mode
			address = talker_address(device_address);
			cmd_buf[0] = address;
			gpib_cmd( cmd_buf, 1 );

			// set myself (controller) to listener mode
			address = listener_address(0);
			cmd_buf[0] = address;
			gpib_cmd( cmd_buf, 1 );

			// read the answer until EOI is detected (then e becomes true)
			do {
				// gpib bus receive
				e = gpib_receive(&b);
				// write out character
				uart_putc(b);
				//if (e)
				//	uart_puts("EOI\n\r");
			} while (!e);
			uart_puts("> ");
			// reset for next command
			is_query=0;
		}

		// SRQ detection - do this every time when time value s has changed
		// s is incremented every second. So we check once a second.
		srq=0;
		if (old_time==0) {
			// old_time value initialization on first call with value s
			old_time=s;
		} else {
			if (s>old_time) {
				// some time has passed - check if srq was set
				srq = bit_is_clear(PIND,G_SRQ);
				if (srq)
					uart_puts("\n\rSRQ detected.\n\r");
			}
		}

		// SRQ handling by doing serial poll
		if (srq) {
			// reset srq for next call
			srq=0;
			// handle srq with serial poll
			address = gpib_serial_poll(device_address,0,0);
			// check status for reason
			buf[0]='E'; 
			buf[1]='V'; 
			buf[2]='E'; 
			buf[3]='N'; 
			buf[4]='T'; 
			buf[5]='?';
			buf[6]='\0';
			buf_ptr=6;
			command_ready=1;		
		}
	}
#else
	uart_puts("\n\rGPIB Listerner Only (L)\n\r");
	//
	// READ test Controller=me is LISTENER ONLY
	//

	// init gpib lines
	gpib_init();

	for(;;) {

		// 
		e = gpib_receive(&b);
		uart_putc(b);
		if (e)
			uart_puts("\n\rEOI\n\r");

		// input processing via rs232
		input_process();

	}
#endif
}


uchar input_process( void ) {
	unsigned int c;
	uchar ch;
	uchar ret=0;

	/*
	 * Get received character from ringbuffer
	 * uart_getc() returns in the lower byte the received character and 
	 * in the higher byte (bitmask) the last receive error
	 * UART_NO_DATA is returned when no data is available.
	 *
	 */
	c = uart_getc();
	if ( c & UART_NO_DATA ) {
		// no data available from UART
		return 0;
	}

	/*
	 * new data available from UART
	 * check for Frame or Overrun error
	 */
	if ( c & UART_FRAME_ERROR ) {
		/* Framing Error detected, i.e no stop bit detected */
		uart_puts_P("UART Frame Error: ");
	}
	if ( c & UART_OVERRUN_ERROR ) {
		/* 
		 * Overrun, a character already present in the UART UDR register was 
		 * not read by the interrupt handler before the next character arrived,
		 * one or more received characters have been dropped
		 */
		uart_puts_P("UART Overrun Error: ");
	}
	if ( c & UART_BUFFER_OVERFLOW ) {
		/* 
		 * We are not reading the receive buffer fast enough,
		 * one or more received character have been dropped 
		 */
		uart_puts_P("Buffer overflow error: ");
	}

	/* 
	 * send received character back
	 */
	uart_putc( (unsigned char)c );

	// make uchar from character in int value
	ch = (uchar) c;
	// add to buffer
	buf[buf_ptr++] = ch;
	// terminate string
	buf[buf_ptr] = '\0';

	// <CR> means command input is complete
	if (ch==0x0d) {
		// adjust string terminator
		buf[--buf_ptr]='\0';
		ret=1;
	}

	return ret;
}

