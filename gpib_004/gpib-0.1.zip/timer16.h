/*************************************************************************
Author:   	$Author: dennis $
File:     	$HeadURL: file:///home/dennis/svn-store/gpib_004/timer16.h $
Date:  		$Date: 2008-03-26 19:03:40 +0100 (Mi, 26 Mrz 2008) $ 
Revision: 	$Revision: 43 $ 
Id: 		$Id: timer16.h 43 2008-03-26 18:03:40Z dennis $ 
Licence:	GNU General Public License

DESCRIPTION:
  16 Bit timer implementation. 
 *************************************************************************/
#ifndef TIMER16_H_
#define TIMER16_H_

#include "defs.h"

#define DEBOUNCE 256L /* so oft wollen wir die ISR aufgerufen haben */

extern volatile uchar timer; // timer value
extern volatile uchar s; // second value

void timer16_init( void );

#endif /*TIMER16_H_*/
