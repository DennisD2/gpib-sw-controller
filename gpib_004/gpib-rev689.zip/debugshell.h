/*************************************************************************
Author:   	$Author: dennis $
File:     	$HeadURL: file://localhost/home/dennis/svn-store/avr-source/gpib_004/debugshell.h $
Date:  		$Date: 2008-05-11 07:57:02 +0200 (So, 11 Mai 2008) $ 
Revision: 	$Revision: 65 $ 
Id: 		$Id: debugshell.h 65 2008-05-11 05:57:02Z dennis $ 
Licence:	GNU General Public License

DESCRIPTION:
  debug shell implementation. 
 *************************************************************************/
#ifndef DEBUGSHELL_H_
#define DEBUGSHELL_H_

#include "defs.h"

extern void debugshell( void );


#endif /* DEBUGSHELL_H_ */
